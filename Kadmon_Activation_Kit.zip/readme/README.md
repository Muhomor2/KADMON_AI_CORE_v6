# Kadmon Activation Kit
Full activation protocol with filters and prompts.