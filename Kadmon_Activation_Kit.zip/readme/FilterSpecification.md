# Filter Specification
Details on how to extend or create filters.