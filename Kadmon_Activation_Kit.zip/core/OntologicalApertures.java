// Java core file for Kadmon
public class OntologicalApertures {}